"use client"

import * as React from "react"

import { cn } from "@/lib/utils"
import type { Status, Task } from "@/lib/types"
import { TaskCard } from "@/components/task-card"

interface KanbanColumnProps {
  id: Status
  label: string
  hint: string
  tasks: Task[]
  draggingId: string | null
  isActiveDropTarget: boolean
  onDragStart: (id: string) => void
  onDragEnd: () => void
  onDropTask: (status: Status) => void
  onDragOverColumn: (status: Status) => void
  onDragLeaveColumn: () => void
  onDelete: (id: string) => void
}

export function KanbanColumn({
  id,
  label,
  hint,
  tasks,
  draggingId,
  isActiveDropTarget,
  onDragStart,
  onDragEnd,
  onDropTask,
  onDragOverColumn,
  onDragLeaveColumn,
  onDelete,
}: KanbanColumnProps) {
  return (
    <section
      aria-label={label}
      onDragOver={(e) => {
        e.preventDefault()
        onDragOverColumn(id)
      }}
      onDragLeave={(e) => {
        // Only clear when leaving the column bounds, not entering a child.
        if (!e.currentTarget.contains(e.relatedTarget as Node | null)) {
          onDragLeaveColumn()
        }
      }}
      onDrop={(e) => {
        e.preventDefault()
        onDropTask(id)
      }}
      className={cn(
        "flex min-h-64 flex-col gap-3 rounded-2xl border border-dashed bg-muted/40 p-3 transition-colors",
        isActiveDropTarget && draggingId
          ? "border-primary bg-primary/5"
          : "border-border",
      )}
    >
      <header className="flex items-center justify-between px-1">
        <div className="flex items-center gap-2">
          <span
            className={cn(
              "size-2 rounded-full",
              id === "todo" && "bg-chart-4",
              id === "doing" && "bg-chart-3",
              id === "done" && "bg-primary",
            )}
          />
          <h2 className="text-sm font-semibold">{label}</h2>
          <span className="rounded-full bg-background px-2 py-0.5 text-xs font-medium tabular-nums text-muted-foreground">
            {tasks.length}
          </span>
        </div>
        <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
          {hint}
        </span>
      </header>

      <div className="flex flex-1 flex-col gap-2.5">
        {tasks.map((task) => (
          <TaskCard
            key={task.id}
            task={task}
            isDragging={draggingId === task.id}
            onDragStart={onDragStart}
            onDragEnd={onDragEnd}
            onDelete={onDelete}
          />
        ))}

        {tasks.length === 0 ? (
          <div className="flex flex-1 items-center justify-center rounded-xl border border-dashed border-border/60 py-8 text-center text-xs text-muted-foreground">
            Drop tasks here
          </div>
        ) : null}
      </div>
    </section>
  )
}
