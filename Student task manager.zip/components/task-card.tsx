"use client"

import { CalendarIcon, GripVerticalIcon, Trash2Icon } from "lucide-react"

import { cn } from "@/lib/utils"
import type { Priority, Task } from "@/lib/types"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

const PRIORITY_STYLES: Record<Priority, string> = {
  High: "bg-priority-high text-priority-high-foreground",
  Medium: "bg-priority-medium text-priority-medium-foreground",
  Low: "bg-priority-low text-priority-low-foreground",
}

interface TaskCardProps {
  task: Task
  isDragging: boolean
  onDragStart: (id: string) => void
  onDragEnd: () => void
  onDelete: (id: string) => void
}

export function TaskCard({
  task,
  isDragging,
  onDragStart,
  onDragEnd,
  onDelete,
}: TaskCardProps) {
  const deadline = task.deadline ? new Date(task.deadline + "T00:00:00") : null
  const isOverdue =
    deadline !== null && task.status !== "done" && deadline < startOfToday()

  return (
    <article
      draggable
      onDragStart={() => onDragStart(task.id)}
      onDragEnd={onDragEnd}
      className={cn(
        "group relative cursor-grab rounded-xl border bg-card p-3.5 shadow-sm transition-all active:cursor-grabbing hover:border-primary/40 hover:shadow-md",
        isDragging && "opacity-40 ring-2 ring-primary",
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <Badge className={cn("border-0 font-medium", PRIORITY_STYLES[task.priority])}>
          {task.priority}
        </Badge>
        <div className="flex items-center gap-0.5">
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label="Delete task"
            onClick={() => onDelete(task.id)}
            className="text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100 hover:text-destructive"
          >
            <Trash2Icon />
          </Button>
          <GripVerticalIcon className="size-4 text-muted-foreground/50" />
        </div>
      </div>

      <h3 className="mt-2 text-sm font-medium leading-snug text-balance">
        {task.title}
      </h3>

      {task.description ? (
        <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-muted-foreground">
          {task.description}
        </p>
      ) : null}

      <div className="mt-3 flex flex-wrap items-center gap-2">
        {task.course ? (
          <span className="rounded-md bg-muted px-2 py-0.5 font-mono text-[10px] uppercase tracking-wide text-muted-foreground">
            {task.course}
          </span>
        ) : null}
        {deadline ? (
          <span
            className={cn(
              "flex items-center gap-1 text-xs",
              isOverdue ? "font-medium text-destructive" : "text-muted-foreground",
            )}
          >
            <CalendarIcon className="size-3" />
            {formatDeadline(deadline)}
            {isOverdue ? " · overdue" : ""}
          </span>
        ) : null}
      </div>
    </article>
  )
}

function startOfToday() {
  const d = new Date()
  d.setHours(0, 0, 0, 0)
  return d
}

function formatDeadline(date: Date) {
  return date.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
  })
}
