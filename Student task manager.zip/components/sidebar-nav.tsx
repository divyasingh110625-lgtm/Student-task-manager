"use client"

import {
  LayoutDashboardIcon,
  CalendarIcon,
  BookOpenIcon,
  ArchiveIcon,
  SettingsIcon,
  GraduationCapIcon,
} from "lucide-react"

import { cn } from "@/lib/utils"
import { Progress } from "@/components/ui/progress"

const NAV_ITEMS = [
  { label: "Board", icon: LayoutDashboardIcon, active: true },
  { label: "Calendar", icon: CalendarIcon, active: false },
  { label: "Courses", icon: BookOpenIcon, active: false },
  { label: "Archive", icon: ArchiveIcon, active: false },
  { label: "Settings", icon: SettingsIcon, active: false },
]

interface SidebarNavProps {
  total: number
  done: number
  percent: number
}

export function SidebarNav({ total, done, percent }: SidebarNavProps) {
  return (
    <div className="flex h-full flex-col gap-6 p-4">
      <div className="flex items-center gap-2.5 px-2">
        <div className="flex size-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
          <GraduationCapIcon className="size-5" />
        </div>
        <div className="flex flex-col">
          <span className="text-sm font-semibold leading-tight">Semester</span>
          <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            Task Manager
          </span>
        </div>
      </div>

      <nav className="flex flex-col gap-1" aria-label="Main">
        {NAV_ITEMS.map((item) => (
          <button
            key={item.label}
            type="button"
            aria-current={item.active ? "page" : undefined}
            className={cn(
              "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
              item.active
                ? "bg-sidebar-accent text-sidebar-accent-foreground"
                : "text-muted-foreground hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground",
            )}
          >
            <item.icon className="size-4 shrink-0" />
            {item.label}
          </button>
        ))}
      </nav>

      <div className="mt-auto flex flex-col gap-3 rounded-xl border bg-card p-4">
        <div className="flex items-baseline justify-between">
          <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            Overall Progress
          </span>
          <span className="text-sm font-semibold tabular-nums">{percent}%</span>
        </div>
        <Progress value={percent} />
        <p className="text-xs text-muted-foreground">
          <span className="font-medium text-foreground tabular-nums">
            {done}
          </span>{" "}
          of{" "}
          <span className="font-medium text-foreground tabular-nums">
            {total}
          </span>{" "}
          tasks completed
        </p>
      </div>
    </div>
  )
}
