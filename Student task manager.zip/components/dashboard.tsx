"use client"

import * as React from "react"
import { MenuIcon } from "lucide-react"

import type { Status, Task } from "@/lib/types"
import { COLUMNS, INITIAL_TASKS } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import {
  Sheet,
  SheetContent,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet"
import { SidebarNav } from "@/components/sidebar-nav"
import { ThemeToggle } from "@/components/theme-toggle"
import { AddTaskDialog } from "@/components/add-task-dialog"
import { KanbanColumn } from "@/components/kanban-column"

export function Dashboard() {
  const [tasks, setTasks] = React.useState<Task[]>(INITIAL_TASKS)
  const [draggingId, setDraggingId] = React.useState<string | null>(null)
  const [dropTarget, setDropTarget] = React.useState<Status | null>(null)

  const total = tasks.length
  const done = tasks.filter((t) => t.status === "done").length
  const percent = total === 0 ? 0 : Math.round((done / total) * 100)

  function addTask(task: Omit<Task, "id">) {
    setTasks((prev) => [
      { ...task, id: `t${Date.now()}` },
      ...prev,
    ])
  }

  function deleteTask(id: string) {
    setTasks((prev) => prev.filter((t) => t.id !== id))
  }

  function handleDropTask(status: Status) {
    if (!draggingId) return
    setTasks((prev) =>
      prev.map((t) => (t.id === draggingId ? { ...t, status } : t)),
    )
    setDraggingId(null)
    setDropTarget(null)
  }

  return (
    <div className="flex min-h-screen bg-background text-foreground">
      {/* Desktop sidebar */}
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 border-r bg-sidebar text-sidebar-foreground md:block">
        <SidebarNav total={total} done={done} percent={percent} />
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-10 flex items-center gap-3 border-b bg-background/80 px-4 py-3 backdrop-blur-md sm:px-6">
          {/* Mobile sidebar trigger */}
          <Sheet>
            <SheetTrigger
              render={
                <Button variant="outline" size="icon" className="md:hidden" />
              }
              aria-label="Open menu"
            >
              <MenuIcon />
            </SheetTrigger>
            <SheetContent
              side="left"
              className="w-72 bg-sidebar p-0 text-sidebar-foreground"
            >
              <SheetTitle className="sr-only">Navigation</SheetTitle>
              <SidebarNav total={total} done={done} percent={percent} />
            </SheetContent>
          </Sheet>

          <div className="min-w-0 flex-1">
            <h1 className="truncate text-lg font-semibold">My Board</h1>
            <p className="hidden text-xs text-muted-foreground sm:block">
              Stay on top of assignments and deadlines.
            </p>
          </div>

          <ThemeToggle />
          <AddTaskDialog onAdd={addTask} />
        </header>

        <main className="flex flex-1 flex-col gap-6 p-4 sm:p-6">
          {/* Progress overview */}
          <section className="rounded-2xl border bg-card p-4 sm:p-5">
            <div className="flex items-center justify-between gap-4">
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                  Overall Completion
                </p>
                <p className="mt-1 text-2xl font-semibold tabular-nums">
                  {percent}%
                </p>
              </div>
              <div className="flex gap-4 text-right sm:gap-6">
                {COLUMNS.map((c) => (
                  <div key={c.id}>
                    <p className="text-xl font-semibold tabular-nums">
                      {tasks.filter((t) => t.status === c.id).length}
                    </p>
                    <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                      {c.label}
                    </p>
                  </div>
                ))}
              </div>
            </div>
            <Progress value={percent} className="mt-4" />
          </section>

          {/* Kanban board */}
          <div className="grid flex-1 grid-cols-1 gap-4 md:grid-cols-3">
            {COLUMNS.map((column) => (
              <KanbanColumn
                key={column.id}
                id={column.id}
                label={column.label}
                hint={column.hint}
                tasks={tasks.filter((t) => t.status === column.id)}
                draggingId={draggingId}
                isActiveDropTarget={dropTarget === column.id}
                onDragStart={setDraggingId}
                onDragEnd={() => {
                  setDraggingId(null)
                  setDropTarget(null)
                }}
                onDropTask={handleDropTask}
                onDragOverColumn={setDropTarget}
                onDragLeaveColumn={() => setDropTarget(null)}
                onDelete={deleteTask}
              />
            ))}
          </div>
        </main>
      </div>
    </div>
  )
}
