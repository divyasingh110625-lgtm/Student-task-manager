import { ThemeProvider } from "@/components/theme-provider"
import { Dashboard } from "@/components/dashboard"

export default function Page() {
  return (
    <ThemeProvider>
      <Dashboard />
    </ThemeProvider>
  )
}
