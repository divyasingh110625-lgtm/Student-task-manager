export type Priority = "High" | "Medium" | "Low"

export type Status = "todo" | "doing" | "done"

export interface Task {
  id: string
  title: string
  description?: string
  course?: string
  priority: Priority
  status: Status
  deadline?: string // ISO date string (yyyy-mm-dd)
}

export const COLUMNS: { id: Status; label: string; hint: string }[] = [
  { id: "todo", label: "To-Do", hint: "Not started" },
  { id: "doing", label: "Doing", hint: "In progress" },
  { id: "done", label: "Done", hint: "Completed" },
]

export const PRIORITIES: Priority[] = ["High", "Medium", "Low"]

export const INITIAL_TASKS: Task[] = [
  {
    id: "t1",
    title: "Read chapters 4–6",
    description: "Cover diffusion and osmosis before Friday's quiz.",
    course: "Biology 201",
    priority: "High",
    status: "todo",
    deadline: addDays(2),
  },
  {
    id: "t2",
    title: "Problem set 3",
    description: "Complete derivatives worksheet, questions 1–20.",
    course: "Calculus I",
    priority: "Medium",
    status: "todo",
    deadline: addDays(5),
  },
  {
    id: "t3",
    title: "Draft literature review",
    description: "Outline sources for the term paper.",
    course: "English Lit",
    priority: "Low",
    status: "todo",
    deadline: addDays(9),
  },
  {
    id: "t4",
    title: "Lab report: titration",
    description: "Write up results and error analysis.",
    course: "Chemistry",
    priority: "High",
    status: "doing",
    deadline: addDays(1),
  },
  {
    id: "t5",
    title: "Group project slides",
    description: "Build the intro and methodology sections.",
    course: "Sociology",
    priority: "Medium",
    status: "doing",
    deadline: addDays(4),
  },
  {
    id: "t6",
    title: "Weekly reading response",
    course: "History 110",
    priority: "Low",
    status: "done",
    deadline: addDays(-1),
  },
  {
    id: "t7",
    title: "Register for spring courses",
    course: "Advising",
    priority: "Medium",
    status: "done",
    deadline: addDays(-3),
  },
]

function addDays(days: number): string {
  const d = new Date()
  d.setDate(d.getDate() + days)
  return d.toISOString().slice(0, 10)
}
